package com.example.projectdam;

import android.content.Intent;
import android.content.SharedPreferences;
import android.media.session.MediaSession;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.lifecycle.SavedStateHandle;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

public class Add_Input extends AppCompatActivity  {

    Button add,cancel;

    EditText ReadingName,ReadingType,ReadingUnit,ReadingFreq,ReadingTemp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_input);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ReadingName=findViewById(R.id.Edit_ReadingName);
        ReadingType=findViewById(R.id.Edit_ReadingType);
        ReadingUnit=findViewById(R.id.Edit_ReadingUnit);
        ReadingFreq=findViewById(R.id.Frequency_edit);
        ReadingTemp=findViewById(R.id.Temperature_edit);

        cancel=findViewById(R.id.Cancel_input_reading);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Add_Input.this, InputReading.class);
                startActivity(intent);
            }
        });

        add=findViewById(R.id.Submit_Add);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Add_Input_Reading();
            }
        });
    }
    public void Add_Input_Reading() {

        String name = ReadingName.getText().toString().trim();
//        String type = ReadingType.getText().toString().trim();
//        String unit = ReadingUnit.getText().toString().trim();
        String frequency = ReadingFreq.getText().toString().trim();
        String temperature = ReadingTemp.getText().toString().trim();

        if (name.isEmpty()  || frequency.isEmpty() || temperature.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }
        RequestQueue queue=Volley.newRequestQueue(Add_Input.this);
        String Url = "http://3.238.243.80:9090/DamMonitoring/readings/add";

        String freqText = ReadingFreq.getText().toString();
        String tempText = ReadingTemp.getText().toString();
        double freq = Double.parseDouble(freqText);
        double temp = Double.parseDouble(tempText);

        JSONObject jsonbody=new JSONObject();
        {
            try {
                jsonbody.put("name",ReadingName.getText().toString());
                jsonbody.put("type",ReadingType.getText().toString());
                jsonbody.put("unit",ReadingUnit.getText().toString());
                jsonbody.put("freq",freq);
                jsonbody.put("temp",temp);
            }
            catch (JSONException e) {
                e.printStackTrace();
            }
        }

        JsonObjectRequest jsonObjectRequest=new JsonObjectRequest(
                Request.Method.POST,
                Url,
                jsonbody ,
              new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response)
                    {
                      Toast.makeText(Add_Input.this,"Added Successfully",Toast.LENGTH_LONG).show();
                        ReadingName.setText("");
                        ReadingFreq.setText("");
                        ReadingTemp.setText("");
                    }
                },
              new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(Add_Input.this, "Error : " + error.toString(),Toast.LENGTH_LONG).show();
                        Log.d("VolleyDebug", "URL: " + Url);
                        Log.d("VolleyDebug", "Body: " + jsonbody.toString());
                        Log.e("VolleyError", "Error: " + error.toString(), error);
                    }
                });
//        {
//            @Override
//            public Map<String, String> getHeaders() throws AuthFailureError {
//                Map<String, String> headers = new HashMap<>();
//                headers.put("Content-Type", "application/json");
//                headers.put("Accept", "application/json");
//
//                SharedPreferences preferences=getSharedPreferences("Shared_preferences", MODE_PRIVATE);
//                String token =preferences.getString("access_token","");
//                headers.put("Authorization", "Bearer " + token);
//                return headers;
//            }
//        }
        queue.add(jsonObjectRequest);
    }
}