package com.example.projectdam;

import android.content.Intent;
import android.content.SharedPreferences;
import android.media.session.MediaSession;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.json.JSONException;
import org.json.JSONObject;

public class Dashboard extends AppCompatActivity {
    ImageView Sensor,Input,Report ,Graph;
    TextView textView;
//    CardView cardView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_dashboard);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

//        textView=findViewById(R.id.token);
//        cardView=findViewById(R.id.card_1);
//        cardView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                System.out.println("HELLO");
//
//            }
//        });

        Input=findViewById(R.id.InputReding);
        Input.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Dashboard.this, InputReading.class);
                startActivity(intent);
            }
        });

        Sensor=findViewById(R.id.Sensor);
        Sensor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Dashboard.this,SensorManagement.class);
                startActivity(intent);
            }
        });

        Report=findViewById(R.id.Report);
        Report.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(Dashboard.this, Report.class);
                startActivity(intent);
            }
        });
        Graph=findViewById(R.id.Graph);
        Graph.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(Dashboard.this, Graph.class);
                startActivity(intent);
            }
        });

//        String response;
//        SharedPreferences preferences=getSharedPreferences("Shared_preferences",MODE_PRIVATE);
//        response=preferences.getString("Api_Response","");

        String token;
        SharedPreferences preferences=getSharedPreferences("Shared_preferences",MODE_PRIVATE);
        token = preferences.getString("token","");

//        if (token != null && !token.isEmpty()) {
//
//            textView.setText("Token: " + token);
//        } else {
//            textView.setText("No token saved yet");
//        }
    }
}