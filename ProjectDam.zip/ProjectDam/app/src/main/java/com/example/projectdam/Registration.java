package com.example.projectdam;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class Registration extends AppCompatActivity{
    Button Register,Cancel;
    EditText Username,Email,PhoneNumber,Password,Confirm_password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_registration);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Username=findViewById(R.id.Username_Edit);
        Email=findViewById(R.id.Email_Edit);
        PhoneNumber=findViewById(R.id.PhoneNumber_Edit);
        Password=findViewById(R.id.Password_Edit);
        Confirm_password=findViewById(R.id.ConfrimPasswordEdit);


        Cancel=findViewById(R.id.cancel_button);
        Cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Registration.this, MainActivity.class);
                startActivity(intent);
            }
        });


        Register=findViewById(R.id.Register);
        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Registration.this,MainActivity.class);
                startActivity(intent);

//                RequestRegistrationPost();
            }
        });
    }

//    public void RequestRegistrationPost() {
//
//            String username = Username.getText().toString().trim();
//            String email = Email.getText().toString().trim();
//            String phone = PhoneNumber.getText().toString().trim();
//            String password = Password.getText().toString().trim();
//            String confirmPassword = Confirm_password.getText().toString().trim();
//
//            if (username.isEmpty() || email.isEmpty() || phone.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
//                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
//                return;
//            }
//
//            if (!password.equals(confirmPassword)) {
//                Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
//                return;
//            }
//
//            RequestQueue queue= Volley.newRequestQueue(Registration.this);
//
//            String Url="http://10.0.2.2:8082/auth/register";
//
//            JSONObject jsonbody = new JSONObject();
//            {
//                try {
//                    jsonbody.put("username", Username.getText().toString());
//                    jsonbody.put("email", Email.getText().toString());
//                    jsonbody.put("phone", PhoneNumber.getText().toString());
//                    jsonbody.put("password", Password.getText().toString());
//                } catch (JSONException e) {
//                    e.printStackTrace();
//                }
//            }
//            JsonObjectRequest jsonObjectRequest=new JsonObjectRequest(
//                    Request.Method.POST,
//                    Url,
//                    jsonbody,
//                    new Response.Listener<JSONObject>() {
//                        @Override
//                        public void onResponse(JSONObject response) {
//                            Toast.makeText(Registration.this,"User registered successfully : " + response.toString(),Toast.LENGTH_LONG).show();
//                           Intent intent=new Intent(Registration.this,MainActivity.class);
//                           startActivity(intent);
//                        }
//                    },
//                    new Response.ErrorListener() {
//                        @Override
//                        public void onErrorResponse(VolleyError error) {
//                            Toast.makeText(Registration.this, "Error : " + error.toString(),Toast.LENGTH_LONG).show();
//                            Log.e("VolleyError", "Error: " + error.toString(), error);
//                            Log.d("VolleyDebug", "URL: " + Url);
//                            Log.d("VolleyDebug", "Body: " + jsonbody.toString());
//                        }
//                    }
//            );
//            queue.add(jsonObjectRequest);
//    }
}