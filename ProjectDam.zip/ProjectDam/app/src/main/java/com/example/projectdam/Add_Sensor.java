package com.example.projectdam;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.ref.ReferenceQueue;
import java.util.HashMap;
import java.util.Map;

public class Add_Sensor extends AppCompatActivity {

    Button SensorAdd,SensorCancel;

    EditText Sensor_name,Sensor_type,Sensor_unit,Sensor_ir,Sensor_linearCoeff,Sensor_minRange,Sensor_maxRange,Sensor_location,Sensor_description;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_sensor);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        Sensor_name=findViewById(R.id.Edit_SensorName);
        Sensor_type=findViewById(R.id.Edit_SensorType);
        Sensor_unit=findViewById(R.id.Edit_SensorUnit);
        Sensor_ir=findViewById(R.id.edit_Ir);
        Sensor_linearCoeff=findViewById(R.id.edit_linearCoeff);
        Sensor_minRange=findViewById(R.id.edit_minRange);
        Sensor_maxRange=findViewById(R.id.edit_maxRange);
        Sensor_location=findViewById(R.id.edit_location);
        Sensor_description=findViewById(R.id.edit_description);


        SensorAdd=findViewById(R.id.Sensor_Add_Submit);
        SensorAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Add_Sensor.this,SensorManagement.class);
                startActivity(intent);
//                AddSensor();
            }
        });

        SensorCancel=findViewById(R.id.Sensor_Add_Cancel);
        SensorCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Add_Sensor.this,SensorManagement.class);
                startActivity(intent);
            }
        });
    }

//    public void AddSensor(){
//
//        RequestQueue queue= Volley.newRequestQueue(Add_Sensor.this);
//
//        String Url = "http://10.0.2.2:8082/sensors/add";
//
//        JSONObject jsonbody=new JSONObject();
//        {
//            try {
//
//                jsonbody.put("name",Sensor_name.getText().toString());
//                jsonbody.put("type",Sensor_type.getText().toString());
//                jsonbody.put("unit",Sensor_unit.getText().toString());
//                jsonbody.put("ir",Sensor_ir.getText().toString());
//                jsonbody.put("linearCoeff",Sensor_linearCoeff.getText().toString());
//                jsonbody.put("minRange",Sensor_minRange.getText().toString());
//                jsonbody.put("maxRange",Sensor_maxRange.getText().toString());
//                jsonbody.put("location",Sensor_location.getText().toString());
//                jsonbody.put("description",Sensor_description.getText().toString());
//            }
//            catch (JSONException e) {
//                throw new RuntimeException(e);
//            }
//        }
//
//        JsonObjectRequest jsonObjectRequest=new JsonObjectRequest(
//                Request.Method.POST,
//                Url,
//                jsonbody,
//                new Response.Listener<JSONObject>() {
//                    @Override
//                    public void onResponse(JSONObject response) {
//                        Toast.makeText(Add_Sensor.this,"Success:"+response.toString(),Toast.LENGTH_LONG).show();
//                        Intent intent=new Intent(Add_Sensor.this,SensorManagement.class);
//                        startActivity(intent);
//                    }
//                }, new Response.ErrorListener() {
//            @Override
//            public void onErrorResponse(VolleyError error) {
//                Toast.makeText(Add_Sensor.this, "Error : " + error.toString(),Toast.LENGTH_LONG).show();
//                Log.d("VolleyDebug", "URL: " + Url);
//                Log.d("VolleyDebug", "Body: " + jsonbody.toString());
//                Log.e("VolleyError", "Error: " + error.toString(), error);
//
//            }
//        })
//        {
//            @Override
//            public Map<String, String> getHeaders() throws AuthFailureError {
//                Map<String, String> headers = new HashMap<>();
//                headers.put("Content-Type", "application/json");
//                headers.put("Accept", "application/json");
//
//                SharedPreferences preferences=getSharedPreferences("Shared_preferences", MODE_PRIVATE);
//                String token =preferences.getString("access_token","");
//                headers.put("Authorization", "Bearer " + token);
//            return headers;
//            }
//        };
//        queue.add(jsonObjectRequest);
//    }
}