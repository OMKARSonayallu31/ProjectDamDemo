package com.example.projectdam;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    TextView SignUp;
    Button Login,b;
    EditText UsernameLogin,PasswordLogin;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        UsernameLogin=findViewById(R.id.Username_edit);
        PasswordLogin=findViewById(R.id.Password_edit);

        SignUp=findViewById(R.id.RegisterNow);
        SignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this, Registration.class);
                startActivity(intent);
            }
        });

        b=findViewById(R.id.buttonLogin);
        b.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {

               String loginemail = UsernameLogin.getText().toString().trim();
               String loginpassword = PasswordLogin.getText().toString().trim();

               if (loginemail.isEmpty() || loginpassword.isEmpty()) {
                   Toast.makeText(MainActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                   return;
               }
               if(loginemail.equalsIgnoreCase("admin") && loginpassword.equalsIgnoreCase("admin")) {
                   Intent intent = new Intent(MainActivity.this, Dashboard.class);
                   startActivity(intent);
                   finish();
               }
               else{
                   Toast.makeText(MainActivity.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
               }
//               RequestPost();
           }
       });
    }

//    public void RequestPost(){
//
//        String Url ="http://10.0.2.2:8082/auth/login";
//        RequestQueue queue = Volley.newRequestQueue(MainActivity.this);
//
//        JSONObject jsonbody = new JSONObject();
//        {
//            try {
//                jsonbody.put("email", UsernameLogin.getText().toString());
//                jsonbody.put("password", PasswordLogin.getText().toString());
//            } catch (JSONException e) {
//                e.printStackTrace();
//            }
//        }
//// Api Reguest
//
//        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
//                Request.Method.POST,
//                Url,
//                jsonbody,
//                new Response.Listener<JSONObject>() {
//
//                    @Override
//                    public void onResponse(JSONObject response) {
//                        Toast.makeText(MainActivity.this,"Succees : "+response.toString(), Toast.LENGTH_LONG).show();
//                        Intent intent = new Intent(MainActivity.this, Dashboard.class);
//                        startActivity(intent);
//
//                        try {
//                            JSONObject responseObject=response;
//                            JSONObject tokenObject=responseObject.getJSONObject("tokens");
//                            String accessToken=tokenObject.getString("access_token");
//
//                            SharedPreferences preferences=getSharedPreferences("Shared_preferences",MODE_PRIVATE);
//                            SharedPreferences.Editor editor=preferences.edit();
//
//                            editor.putString("token",tokenObject.toString());
//                            editor.putString("access_token",accessToken);
//                            editor.apply();
//
//                        } catch (JSONException e) {
//                            throw new RuntimeException(e);
//                        }
//
////                        SharedPreferences preferences = getSharedPreferences("Shared_preferences", MODE_PRIVATE);
////                        SharedPreferences.Editor editor = preferences.edit();
////                        editor.putString("Api_Response", response.toString());
////                        editor.apply();
//                    }
//                },
//                new Response.ErrorListener() {
//                    @Override
//                    public void onErrorResponse(VolleyError error) {
//                        Toast.makeText(MainActivity.this, "Error :" + error.toString(), Toast.LENGTH_LONG).show();
//                        Log.e("VolleyError", "Error: " + error.toString(), error);
//                        Log.d("VolleyDebug", "URL: " + Url);
//                        Log.d("VolleyDebug", "Body: " + jsonbody.toString());
//                    }
//                }
//        );
//        queue.add(jsonObjectRequest);
//    }
}